# Tool License  
> https://creativecommons.org/licenses/by-sa/4.0/  
  
Feel free to offer me a coffee here:
https://eloistree.page.link/coffee