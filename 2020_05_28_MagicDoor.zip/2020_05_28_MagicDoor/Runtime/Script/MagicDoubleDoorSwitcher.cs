﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using UnityEngine;

public class MagicDoubleDoorSwitcher : MonoBehaviour
{
    public string[] m_resourceFolder = new string[] { "MagicRoomsDemo" };
    public RoomInScene m_roomOne = new RoomInScene();
    public RoomInScene m_roomTwo = new RoomInScene();

    [System.Serializable]
    public class RoomInScene {
      
        public MagicDoorPlayerUserInfo m_roofInfo;
        [Header("Debug")]
        public bool m_hadBeenVisited;
        public bool m_hadBeenViewed;
        public bool m_needToBeRendered;
        public GameObject m_currentPrefabUsed;

        public GameObject GetPrefabUsed()
        {
            return m_currentPrefabUsed;
        }

        public void SetCurrentPrefabUsed(GameObject prefab)
        {
            m_currentPrefabUsed = prefab;
        }
    }

    [Header("Debug")]
    public GameObject[] m_roomPrefabs= new GameObject[0];
    public ShufflableQueue m_roomsQueue;


    public void Awake()
    {
        LoadPrefabLinkFromResources();
        m_roomsQueue = new ShufflableQueue(m_roomPrefabs);
        RequestChangeOnRoom(m_roomOne, true);
        RequestChangeOnRoom(m_roomTwo, true);
    }

    public void Update()
    {
        CheckIfNeedToBeSwitch(m_roomOne);
        CheckIfNeedToBeSwitch(m_roomTwo);

    }

    private void CheckIfNeedToBeSwitch(RoomInScene room)
    {
        bool needToBeRenderedOne = room.m_roofInfo.IsPlayerInRoomOrWatchingIt();
        if (needToBeRenderedOne != room.m_needToBeRendered)
        {
            if (!needToBeRenderedOne)
                RequestChangeOnRoom(room, true);
        }
        room.m_needToBeRendered = needToBeRenderedOne;
    }

    public RoomInScene[] GetRooms() { return new RoomInScene[] { m_roomOne, m_roomTwo }; }

    private void LoadPrefabLinkFromResources()
    {
        List<GameObject> prefabsFound = new List<GameObject>();
        for (int i = 0; i < m_resourceFolder.Length; i++)
        {

            GameObject[] prefabs = Resources.LoadAll<GameObject>(m_resourceFolder[i]);
            if (prefabs != null)
                prefabsFound.AddRange(prefabs);
        }
        m_roomPrefabs = prefabsFound.ToArray(); 

    }

    public void RequestChangeOnRoom( RoomInScene room, bool affectScale)
    {
        if (m_roomPrefabs == null && m_roomPrefabs.Length <= 0)
            return;
        GameObject choosed=null;//= m_roomsQueue.GetCurrent();
        for (int i = 0; i < 10; i++)
        {
            choosed = m_roomsQueue.GetCurrent();
            m_roomsQueue.Next();
            if (choosed != m_roomTwo.GetPrefabUsed() && choosed != m_roomOne.GetPrefabUsed())
                break;
        }
        RequestChangeOnRoom(choosed, room, affectScale);

    }
    public void RequestChangeOnRoom(GameObject prefab, RoomInScene room, bool affectScale) {
        room.SetCurrentPrefabUsed(prefab);
        RemoveContent(room);
        GameObject instance = GameObject.Instantiate(prefab);
        AddContent(room,instance.transform, affectScale);

    }

    private void RemoveContent(RoomInScene room)
    {
        Transform content = room.m_roofInfo.GetContentRoot();
        List<Transform> toDelete= new List<Transform>();
        for (int i = 0; i < content.childCount; i++)
        {
            toDelete.Add(content.GetChild(i));
        }
        for (int i = 0; i < toDelete.Count; i++)
        {
            Destroy(toDelete[i].gameObject);
        }


    }

    private void AddContent(RoomInScene room, Transform instance, bool affectScale)
    {
        instance.transform.parent = room.m_roofInfo.GetContentRoot();
        instance.transform.localPosition = Vector3.zero;
        instance.transform.localRotation = Quaternion.identity;
        if(affectScale)
        instance.transform.localScale = Vector3.one;
    }
}
#region ROOM QUEUE
public class ShufflableQueue
{
    public int m_queueIndex = 0;
    public List<GameObject> m_roomQueue = new List<GameObject>();
    public void ShuffleRoomQueue() { Shuffle<GameObject>(m_roomQueue); }
    private static System.Random rng = new System.Random();
    private GameObject[] roomPrefabs;

    public ShufflableQueue(IEnumerable<GameObject> roomPrefabs)
    {
        m_roomQueue = roomPrefabs.ToList();
        Shuffle<GameObject>(m_roomQueue);
    }

    public GameObject GetCurrent() { return m_roomQueue[m_queueIndex]; }
    public void Next() {
        m_queueIndex++;
        if (m_queueIndex >= m_roomQueue.Count) { 
            m_queueIndex = 0;
            Shuffle<GameObject>(m_roomQueue);
        }
        
    }

    public static void Shuffle<T>(List<T> list)
    {
        int n = list.Count;
        while (n > 1)
        {
            n--;
            int k = rng.Next(n + 1);
            T value = list[k];
            list[k] = list[n];
            list[n] = value;
        }
    }
}
#endregion